/* auth.js — DataShop v1.0 (frontend demo — uses localStorage for mock auth) */
(function() {
  const MOCK_USERS = [
    { email: 'admin@datashop.site',  password: 'admin123', role: 'admin',  name: 'Ama Owusu',    verified: true  },
    { email: 'agent@datashop.site',  password: 'agent123', role: 'agent',  name: 'Kwame Mensah', verified: true  },
    { email: 'test@datashop.site',   password: 'test123',  role: 'agent',  name: 'Kojo Asante',  verified: false },
  ];

  function getSession() {
    try { return JSON.parse(localStorage.getItem('ds_session')); } catch { return null; }
  }
  function setSession(user) { localStorage.setItem('ds_session', JSON.stringify(user)); }
  function clearSession()   { localStorage.removeItem('ds_session'); localStorage.removeItem('ds_wallet'); }

  function isAdminPage()   { return window.location.pathname.includes('/admin/'); }
  function isAgentPage()   { return window.location.pathname.includes('/agent/'); }
  function isVerifyPage()  { return window.location.pathname.includes('verify'); }
  function isPublicPage()  {
    const p = window.location.pathname;
    return !p.includes('/agent/') && !p.includes('/admin/');
  }

  function rootPath() {
    const p = window.location.pathname;
    const depth = (p.match(/\//g) || []).length;
    if (p.includes('/agent/') || p.includes('/admin/')) return '../';
    return './';
  }

  // Route guard
  const session = getSession();

  if (isAdminPage()) {
    if (!session) { window.location.href = rootPath() + 'login.html'; return; }
    if (session.role !== 'admin') { window.location.href = rootPath() + 'agent/dashboard.html'; return; }
  } else if (isAgentPage()) {
    if (!session) { window.location.href = rootPath() + 'login.html'; return; }
    if (session.role !== 'agent' && session.role !== 'admin') { window.location.href = rootPath() + 'login.html'; return; }
    if (!session.verified && !isVerifyPage()) { window.location.href = rootPath() + 'verify.html'; return; }
  }

  // Populate user info in sidebar / topbar
  document.addEventListener('DOMContentLoaded', function() {
    if (!session) return;
    const initials = session.name ? session.name.split(' ').map(n=>n[0]).join('').toUpperCase() : '?';
    document.querySelectorAll('.js-user-name').forEach(el => el.textContent = session.name || 'Agent');
    document.querySelectorAll('.js-user-email').forEach(el => el.textContent = session.email || '');
    document.querySelectorAll('.js-user-role').forEach(el => el.textContent = session.role === 'admin' ? 'Administrator' : 'Sub-Agent');
    document.querySelectorAll('.js-user-initials').forEach(el => el.textContent = initials);

    // Wallet balance
    const wallet = parseFloat(localStorage.getItem('ds_wallet') || '420.00');
    document.querySelectorAll('.js-wallet-balance').forEach(el => el.textContent = 'GH₵ ' + wallet.toFixed(2));
  });

  // Logout
  window.dsLogout = function() {
    clearSession();
    const root = (window.location.pathname.includes('/agent/') || window.location.pathname.includes('/admin/')) ? '../' : './';
    window.location.href = root + 'login.html';
  };

  // Login function
  window.dsLogin = function(email, password) {
    const user = MOCK_USERS.find(u => u.email === email.trim().toLowerCase() && u.password === password);
    if (!user) return { success: false, error: 'Invalid email or password.' };
    setSession({ email: user.email, role: user.role, name: user.name, verified: user.verified });
    if (!localStorage.getItem('ds_wallet')) localStorage.setItem('ds_wallet', '420.00');
    if (user.role === 'admin') return { success: true, redirect: 'admin/dashboard.html' };
    if (!user.verified) return { success: true, redirect: 'verify.html' };
    return { success: true, redirect: 'agent/dashboard.html' };
  };

  // Register function
  window.dsRegister = function(data) {
    setSession({ email: data.email, role: 'agent', name: data.firstName + ' ' + data.lastName, verified: false });
    localStorage.setItem('ds_wallet', '0.00');
    return { success: true, redirect: 'verify.html' };
  };

  window.dsGetSession = getSession;
  window.dsGetWallet  = function() { return parseFloat(localStorage.getItem('ds_wallet') || '0'); };
  window.dsSetWallet  = function(v){ localStorage.setItem('ds_wallet', v.toFixed(2)); };
})();
