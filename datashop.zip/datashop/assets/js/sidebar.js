/* sidebar.js — DataShop v1.0 */
(function() {
  document.addEventListener('DOMContentLoaded', function() {
    const sidebar  = document.getElementById('sidebar');
    const overlay  = document.getElementById('sidebar-overlay');
    const hamBtn   = document.getElementById('hamburger-btn');
    if (!sidebar) return;

    function openSidebar()  { sidebar.classList.add('open'); overlay && overlay.classList.add('active'); }
    function closeSidebar() { sidebar.classList.remove('open'); overlay && overlay.classList.remove('active'); }
    function toggleSidebar(){ sidebar.classList.contains('open') ? closeSidebar() : openSidebar(); }

    if (hamBtn)  hamBtn.addEventListener('click', toggleSidebar);
    if (overlay) overlay.addEventListener('click', closeSidebar);

    // Mark active nav item
    const path = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav-item').forEach(item => {
      const href = item.getAttribute('href') || '';
      if (href && href.split('/').pop() === path) {
        item.classList.add('active');
      }
    });

    // Close sidebar on nav click (mobile)
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', function() {
        if (window.innerWidth <= 1024) closeSidebar();
      });
    });
  });
})();
