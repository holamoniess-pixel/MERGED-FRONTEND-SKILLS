/* theme.js — DataShop v1.0 */
(function() {
  const THEME_KEY = 'ds_theme';
  const root = document.documentElement;

  function setTheme(t) {
    root.setAttribute('data-theme', t);
    localStorage.setItem(THEME_KEY, t);
    document.querySelectorAll('[data-theme-toggle]').forEach(btn => {
      const icon = btn.querySelector('.theme-icon');
      if (icon) icon.textContent = t === 'dark' ? '☀️' : '🌙';
      btn.title = t === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode';
    });
  }

  function toggleTheme() {
    setTheme(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
  }

  // Set theme immediately (no flash)
  setTheme(localStorage.getItem(THEME_KEY) || 'dark');

  // Expose globally
  window.dsTheme = { toggle: toggleTheme, set: setTheme };

  // Wire up buttons after DOM is ready
  document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('[data-theme-toggle]').forEach(btn => {
      btn.addEventListener('click', toggleTheme);
    });
    const current = root.getAttribute('data-theme') || 'dark';
    document.querySelectorAll('[data-theme-toggle]').forEach(btn => {
      const icon = btn.querySelector('.theme-icon');
      if (icon) icon.textContent = current === 'dark' ? '☀️' : '🌙';
    });
  });
})();
