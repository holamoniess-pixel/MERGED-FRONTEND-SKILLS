/* charts.js — DataShop v1.0 */
(function() {
  const goldColor  = '#F59E0B';
  const blueColor  = '#3B82F6';
  const goldAlpha  = 'rgba(245,158,11,0.15)';
  const blueAlpha  = 'rgba(59,130,246,0.15)';

  const baseOpts = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { labels: { color: '#94A3B8', font: { family: 'Inter', size: 12 }, boxWidth: 12 } },
      tooltip: {
        backgroundColor: '#1A2F4A',
        borderColor: 'rgba(255,255,255,0.07)',
        borderWidth: 1,
        titleColor: '#F1F5F9',
        bodyColor: '#94A3B8',
        padding: 12,
        cornerRadius: 8,
      }
    },
    scales: {
      x: { ticks: { color: '#475569', font: { family: 'Inter', size: 11 } }, grid: { color: 'rgba(255,255,255,0.04)' } },
      y: { ticks: { color: '#475569', font: { family: 'Inter', size: 11 } }, grid: { color: 'rgba(255,255,255,0.04)' } },
    }
  };

  window.dsCharts = {

    ordersLine: function(canvasId) {
      const ctx = document.getElementById(canvasId);
      if (!ctx) return;
      const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      const data   = [24, 31, 19, 42, 37, 55, 48];
      return new Chart(ctx, {
        type: 'line',
        data: {
          labels,
          datasets: [{
            label: 'Orders',
            data,
            borderColor: goldColor,
            backgroundColor: goldAlpha,
            borderWidth: 2.5,
            tension: 0.4,
            pointBackgroundColor: goldColor,
            pointBorderColor: '#112138',
            pointBorderWidth: 2,
            pointRadius: 5,
            fill: true,
          }]
        },
        options: { ...baseOpts, plugins: { ...baseOpts.plugins, legend: { display: false } } }
      });
    },

    networkDoughnut: function(canvasId) {
      const ctx = document.getElementById(canvasId);
      if (!ctx) return;
      return new Chart(ctx, {
        type: 'doughnut',
        data: {
          labels: ['MTN', 'Telecel', 'AirtelTigo'],
          datasets: [{
            data: [58, 27, 15],
            backgroundColor: ['rgba(255,204,0,0.8)', 'rgba(227,37,38,0.8)', 'rgba(0,86,162,0.8)'],
            borderColor: ['#FFCC00', '#E32526', '#0056A2'],
            borderWidth: 2,
            hoverOffset: 8,
          }]
        },
        options: {
          responsive: true, maintainAspectRatio: false,
          cutout: '65%',
          plugins: {
            legend: { position: 'bottom', labels: { color: '#94A3B8', font: { family: 'Inter', size: 12 }, padding: 16, boxWidth: 10 } },
            tooltip: baseOpts.plugins.tooltip,
          }
        }
      });
    },

    revenueBar: function(canvasId) {
      const ctx = document.getElementById(canvasId);
      if (!ctx) return;
      const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      const data   = [320, 480, 290, 620, 540, 780, 650];
      return new Chart(ctx, {
        type: 'bar',
        data: {
          labels,
          datasets: [{
            label: 'Revenue (GH₵)',
            data,
            backgroundColor: goldAlpha,
            borderColor: goldColor,
            borderWidth: 1.5,
            borderRadius: 6,
          }]
        },
        options: { ...baseOpts, plugins: { ...baseOpts.plugins, legend: { display: false } } }
      });
    },

    walletArea: function(canvasId) {
      const ctx = document.getElementById(canvasId);
      if (!ctx) return;
      const labels = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
      return new Chart(ctx, {
        type: 'line',
        data: {
          labels,
          datasets: [
            { label: 'Top-ups', data: [500, 820, 340, 680], borderColor: goldColor, backgroundColor: goldAlpha, fill: true, tension: 0.4, borderWidth: 2 },
            { label: 'Spending', data: [280, 490, 210, 410], borderColor: blueColor, backgroundColor: blueAlpha, fill: true, tension: 0.4, borderWidth: 2 },
          ]
        },
        options: { ...baseOpts }
      });
    }
  };
})();
